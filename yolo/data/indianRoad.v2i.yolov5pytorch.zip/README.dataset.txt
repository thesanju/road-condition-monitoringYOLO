# indianRoad > 2024-06-21 1:40pm
https://universe.roboflow.com/snaju/indianroad

Provided by a Roboflow user
License: CC BY 4.0

